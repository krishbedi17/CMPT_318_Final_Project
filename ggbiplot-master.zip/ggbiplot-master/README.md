
<!-- README.md is generated from README.Rmd. Please edit that file -->

**NEWS**: Active development of ggbiplot has moved to
[github.com/friendly/ggbiplot](https://github.com/friendly/ggbiplot).
